# INSTALL STEPS

1.) /ui
2.) npm install

# RUN STEPS

1.) from /ui
2.) npm run start
