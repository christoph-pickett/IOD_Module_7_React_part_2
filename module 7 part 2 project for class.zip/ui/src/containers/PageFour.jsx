const PageFour = () => {
  // VARIABLES/STATE LIVE HERE

  // FUNCTIONS/EFFECTS LIVE HERE

  // RETURN LIVES HERE
  return (
    <div>
      <p>This is page four</p>
    </div>
  );
};

export default PageFour;
