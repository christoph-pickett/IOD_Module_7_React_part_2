const HomePage = () => {
  // VARIABLES/STATE LIVE HERE

  // FUNCTIONS/EFFECTS LIVE HERE

  // RETURN LIVES HERE
  return (
    <div>
      <p>HOME PAGE</p>
    </div>
  );
};

export default HomePage;
