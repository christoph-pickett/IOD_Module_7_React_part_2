const PageThree = () => {
  // VARIABLES/STATE LIVE HERE

  // FUNCTIONS/EFFECTS LIVE HERE

  // RETURN LIVES HERE
  return (
    <div>
      <p>This is page three</p>
    </div>
  );
};

export default PageThree;
